#pragma once

namespace styles
{
	void runDark();
	void runWhite();
	void runClassic();
	// https://bleepcoder.com/imgui/161067945/post-your-color-styles-themes-here
	void runCherry();
}