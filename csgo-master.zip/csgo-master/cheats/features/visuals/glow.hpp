#pragma once

class Glow final
{
public:
	void run();
};

inline Glow glow;